package com.Centum.SaiCars;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SaiCarsApplication {

	public static void main(String[] args) {
		SpringApplication.run(SaiCarsApplication.class, args);
	}

}
