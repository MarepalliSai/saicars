package com.Centum.SaiCars;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SaiCarsApplicationTests {

	@Test
	void contextLoads() {
	}

}
